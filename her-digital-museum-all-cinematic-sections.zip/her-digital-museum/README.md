# HER — An Immersive Cinematic Digital Museum

A responsive React + Vite starter for a private digital exhibition. It includes GSAP/ScrollTrigger reveals, a cinematic hero, editorial artwork frames, keyboard-enabled photo lightbox, video-room placeholder, timeline, and reduced-motion handling.

> The ZIP contains a working starter implementation, not your final personalized exhibition. The supplied prompt did not include personal photos or video files, so the included SVG artworks are clearly labeled placeholders.

## Requirements
- Node.js 18+ (Node 20+ recommended)
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Production build
```bash
npm run build
npm run preview
```

## Add your own photographs
1. Put your image files in `public/assets/gallery/`.
2. Open `src/content.js`.
3. Update each `src`, `alt`, `title`, `caption`, and `frame` value.
4. Replace `hero.svg` and `masterpiece.svg` references if you want different hero/featured artwork.
5. Use descriptive alt text. Do not add dates or personal details unless you want them displayed.

Supported frame values: `classic`, `editorial`, `floating`, `double`, `masterpiece`, `contact`. Use `portrait` or `landscape` for `ratio`.

## Add videos
1. Place your video file(s) under `public/assets/videos/`.
2. Replace the film-room placeholder in `src/App.jsx` with a `<video controls playsInline poster="...">` element and use the actual path.
3. Add a matching poster image under `public/assets/posters/`.
4. Avoid autoplay with sound. Consider MP4/H.264 for broad browser compatibility.

The current film room intentionally tells you where to connect a video rather than inventing a video file path or playing fake media.

## Main project structure
```text
public/
  assets/
    gallery/       # SVG placeholders; replace with personal photos
    posters/       # video poster placeholder
    videos/        # add your videos here
src/
  App.jsx          # sections, interactions, lightbox, GSAP
  content.js       # editable exhibition content
  main.jsx         # app entry point
  styles.css       # responsive visual system
```

## Cinematic section entrances

Each museum room has its own GSAP entrance choreography triggered as it enters the viewport: the opening note rises into view, the portrait gallery reveals framed works in sequence, the interlude quote softly focuses in, the film room uses a split-direction reveal, timeline memories arrive in alternating directions, the featured artwork lifts into its frame, and the closing title opens like a final film scene. These animations reverse when scrolling back above their trigger and respect `prefers-reduced-motion`.

## Features
- GSAP timelines and ScrollTrigger reveal/parallax effects
- Reusable parallax primitives in `src/components/Parallax.jsx` (`ParallaxLayer`, `ParallaxImage`, `ParallaxSection`)
- CSS-based artwork frames and subtle hover treatments
- Responsive layouts for phone, tablet, and desktop
- Photo lightbox with previous/next, Escape, and arrow-key controls
- Mobile navigation
- Reduced-motion support
- Metadata and semantic section structure
- Lazy-loaded gallery media and reserved image aspect ratios

## Notes / limitations
- Replace placeholder SVG art with your own media before publishing.
- The video modal is a setup placeholder; actual video playback must be connected to a real file.
- Google Fonts are loaded from a CDN. Local fonts or system fallbacks are used if unavailable.
- Run the build and test in current Edge, Chrome, and Firefox before publishing. No browser test results are claimed by this starter.


## Reusable parallax components
Import from `src/components/Parallax.jsx`:

```jsx
import { ParallaxLayer, ParallaxImage, ParallaxSection } from "./components/Parallax.jsx";

<ParallaxImage src="/assets/gallery/photo.webp" alt="Describe the photo" speed={0.12} />
<ParallaxLayer speed={0.08}>A floating label or decorative layer</ParallaxLayer>
<ParallaxSection background="#171715" speed={0.06}>A section with subtle scroll depth</ParallaxSection>
```

The `speed` value controls the approximate movement amount. Keep it subtle; the components automatically skip scroll movement when `prefers-reduced-motion: reduce` is enabled and reduce motion on coarse-pointer devices.
