import React, { useRef } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowDown } from "lucide-react";

gsap.registerPlugin(ScrollTrigger, useGSAP);

/** A scroll-scrubbed portal. The same timeline reverses naturally when scrolling upward. */
export default function CinematicGateEntrance() {
  const root = useRef(null);

  useGSAP(() => {
    const section = root.current;
    if (!section) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion) {
      gsap.set(section.querySelectorAll(".gate-entrance__title, .gate-entrance__hint"), { opacity: 1 });
      gsap.set(section.querySelector(".gate-entrance__interior-copy"), { opacity: 1 });
      return;
    }

    const q = (selector) => section.querySelector(selector);
    const timeline = gsap.timeline({
      defaults: { ease: "none" },
      scrollTrigger: {
        trigger: section,
        start: "top top",
        end: () => `+=${Math.round(window.innerHeight * (window.matchMedia("(pointer: coarse)").matches ? 2.1 : 2.7))}`,
        scrub: 0.65,
        pin: true,
        anticipatePin: 1,
        invalidateOnRefresh: true,
      },
    });

    timeline
      .addLabel("approach", 0)
      .to(q(".gate-entrance__title"), { y: -35, opacity: 0, duration: 0.18 }, "approach")
      .to(q(".gate-entrance__hint"), { opacity: 0, duration: 0.12 }, "approach")
      .to(q(".gate-entrance__light"), { opacity: 1, scale: 1.3, duration: 0.3 }, "approach+=0.05")
      .to(q(".gate-entrance__camera"), { scale: 1.14, z: 100, duration: 0.34 }, "approach")
      .to(q(".gate-entrance__left"), { rotationY: -108, xPercent: -7, duration: 0.3, transformOrigin: "left center" }, "approach+=0.2")
      .to(q(".gate-entrance__right"), { rotationY: 108, xPercent: 7, duration: 0.3, transformOrigin: "right center" }, "approach+=0.2")
      .to(q(".gate-entrance__corridor"), { scale: 1.28, z: 190, duration: 0.45 }, "approach+=0.4")
      .to(q(".gate-entrance__walls"), { scale: 1.42, z: 140, duration: 0.45 }, "approach+=0.4")
      .to(q(".gate-entrance__floor"), { scale: 1.55, yPercent: 12, duration: 0.45 }, "approach+=0.4")
      .to(q(".gate-entrance__particles"), { yPercent: -18, opacity: 0.25, duration: 0.45 }, "approach+=0.4")
      .to(q(".gate-entrance__interior-copy"), { opacity: 1, y: 0, duration: 0.2 }, "approach+=0.78")
      .to(q(".gate-entrance__title-small"), { opacity: 1, duration: 0.2 }, "approach+=0.84")
      .to(q(".gate-entrance__camera"), { scale: 1.3, z: 260, duration: 0.16 }, "approach+=0.84");

    return () => timeline.scrollTrigger?.kill();
  }, { scope: root });

  return (
    <section ref={root} className="gate-entrance" aria-label="Cinematic entrance to the HER museum">
      <div className="gate-entrance__camera">
        <div className="gate-entrance__sky" />
        <div className="gate-entrance__corridor">
          <div className="gate-entrance__backlight" />
          <div className="gate-entrance__walls" />
          <div className="gate-entrance__floor" />
          <div className="gate-entrance__interior-copy">
            <span>HER · THE PRIVATE ARCHIVE</span>
            <strong>Every memory<br /><em>begins somewhere.</em></strong>
          </div>
        </div>
        <div className="gate-entrance__light" />
        <div className="gate-entrance__gate-frame" aria-hidden="true">
          <div className="gate-entrance__left gate-door"><span className="gate-door__panel" /><span className="gate-door__ornament">✳</span><span className="gate-door__handle" /></div>
          <div className="gate-entrance__right gate-door"><span className="gate-door__panel" /><span className="gate-door__ornament">✳</span><span className="gate-door__handle" /></div>
          <div className="gate-entrance__lintel" />
        </div>
        <div className="gate-entrance__particles" aria-hidden="true" />
        <div className="gate-entrance__vignette" />
      </div>
      <div className="gate-entrance__title">
        <p className="gate-entrance__eyebrow"><span /> A PRIVATE DIGITAL MUSEUM</p>
        <h2>A world <em>of her.</em></h2>
        <p>Some doors open into a lifetime of memories.</p>
      </div>
      <p className="gate-entrance__title-small">WELCOME TO HER WORLD</p>
      <div className="gate-entrance__hint"><span>SCROLL TO ENTER</span><ArrowDown size={15} strokeWidth={1.4} /></div>
      <span className="gate-entrance__folio">ENTRANCE Nº 001 <i>—</i> HER</span>
    </section>
  );
}
