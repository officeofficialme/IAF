import React, { useRef } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

/**
 * Reusable scroll parallax primitives.
 * Keep movement restrained; disable it for reduced-motion users and touch-first screens.
 */
export function ParallaxLayer({
  children,
  className = "",
  speed = 0.16,
  start = "top bottom",
  end = "bottom top",
  scrub = true,
  axis = "y",
}) {
  const ref = useRef(null);

  useGSAP(() => {
    const el = ref.current;
    if (!el || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const touch = window.matchMedia("(pointer: coarse)").matches;
    const distance = touch ? speed * 0.45 : speed;
    gsap.fromTo(el,
      { [axis]: `${distance * -100}%` },
      {
        [axis]: `${distance * 100}%`,
        ease: "none",
        scrollTrigger: { trigger: el, start, end, scrub, invalidateOnRefresh: true }
      }
    );
  }, { scope: ref, dependencies: [speed, start, end, scrub, axis] });

  return <div ref={ref} className={`parallax-layer ${className}`}>{children}</div>;
}

export function ParallaxImage({
  src,
  alt = "",
  className = "",
  speed = 0.12,
  priority = false,
}) {
  return (
    <div className={`parallax-image ${className}`}>
      <ParallaxLayer className="parallax-image__moving" speed={speed}>
        <img src={src} alt={alt} loading={priority ? "eager" : "lazy"} fetchPriority={priority ? "high" : "auto"} />
      </ParallaxLayer>
    </div>
  );
}

export function ParallaxSection({
  children,
  className = "",
  background,
  speed = 0.08,
}) {
  return (
    <section className={`parallax-section ${className}`} style={background ? { background } : undefined}>
      <ParallaxLayer className="parallax-section__depth" speed={speed}>
        {children}
      </ParallaxLayer>
    </section>
  );
}
