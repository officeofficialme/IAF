import React, { useEffect, useRef, useState } from "react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowDown, ArrowLeft, ArrowRight, X, Play, Menu } from "lucide-react";
import { exhibition } from "./content";
import { ParallaxImage, ParallaxLayer } from "./components/Parallax.jsx";
import CinematicGateEntrance from "./components/CinematicGateEntrance.jsx";

gsap.registerPlugin(ScrollTrigger, useGSAP);

function Artwork({ item, index, onOpen }) {
  return (
    <button
      className={`artwork artwork--${item.frame} artwork--${item.ratio}`}
      onClick={() => onOpen(index)}
      aria-label={`Open ${item.title}: ${item.alt}`}
    >
      <span className="artwork__mat">
        <img src={item.src} alt={item.alt} loading="lazy" />
      </span>
      <span className="artwork__caption">
        <span className="artwork__number">{String(item.id).padStart(2, "0")} / HER</span>
        <span className="artwork__title">{item.title}</span>
        <span className="artwork__description">{item.caption}</span>
        <span className="artwork__open">View artwork ↗</span>
      </span>
    </button>
  );
}

function Lightbox({ items, index, onClose, onChange }) {
  const item = items[index];
  const closeRef = useRef(null);
  useEffect(() => {
    if (index < 0) return;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onChange((index + 1) % items.length);
      if (e.key === "ArrowLeft") onChange((index - 1 + items.length) % items.length);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = oldOverflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [index, items.length, onClose, onChange]);
  if (index < 0 || !item) return null;
  return (
    <div className="lightbox" role="dialog" aria-modal="true" aria-label="Artwork viewer" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <button className="lightbox__close icon-button" ref={closeRef} onClick={onClose} aria-label="Close viewer"><X /></button>
      <button className="lightbox__prev icon-button" onClick={() => onChange((index - 1 + items.length) % items.length)} aria-label="Previous artwork"><ArrowLeft /></button>
      <figure className="lightbox__figure">
        <img src={item.src} alt={item.alt} />
        <figcaption><span>{String(item.id).padStart(2, "0")} / {item.title}</span><span>{item.caption}</span></figcaption>
      </figure>
      <button className="lightbox__next icon-button" onClick={() => onChange((index + 1) % items.length)} aria-label="Next artwork"><ArrowRight /></button>
    </div>
  );
}

export default function App() {
  const root = useRef(null);
  const [activeArtwork, setActiveArtwork] = useState(-1);
  const [menuOpen, setMenuOpen] = useState(false);
  const [videoOpen, setVideoOpen] = useState(false);

  useGSAP(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion) {
      gsap.set(".reveal, .artwork, .room-heading, .section-kicker, .timeline-item, .masterpiece__image, .film__poster, .interlude__mark", { opacity: 1, clearProps: "all" });
      return;
    }

    // The hero keeps its own editorial intro animation on page load.
    const intro = gsap.timeline({ defaults: { ease: "power3.out" } });
    intro.from(".hero__eyebrow", { opacity: 0, y: 14, duration: 0.7 })
      .from(".hero__title-line", { yPercent: 115, duration: 1.05, stagger: 0.12 }, "-=0.25")
      .from(".hero__subtitle, .hero__scroll", { opacity: 0, y: 12, duration: 0.7, stagger: 0.15 }, "-=0.35")
      .from(".hero__image-wrap", { clipPath: "inset(12% 12% 12% 12%)", scale: 1.06, duration: 1.4 }, 0.2);

    gsap.to(".hero__image", {
      yPercent: 13, ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true }
    });

    // Every room has its own entrance choreography. These timelines replay in reverse
    // when the visitor scrolls back up, so each section feels like entering a new room.
    const roomTrigger = (section, build) => {
      const el = document.querySelector(section);
      if (!el) return;
      const tl = gsap.timeline({
        defaults: { ease: "power3.out" },
        scrollTrigger: {
          trigger: el,
          start: "top 78%",
          toggleActions: "play none none reverse",
          invalidateOnRefresh: true,
        }
      });
      build(tl, el);
    };

    // 01 — Intro: typography rises like a curtain, the side note follows.
    roomTrigger(".intro", (tl, el) => {
      tl.from(el.querySelector(".section-kicker"), { opacity: 0, y: 18, duration: 0.55 })
        .from(el.querySelector(".intro__large"), { opacity: 0, y: 55, rotateX: -5, transformOrigin: "left top", duration: 1.0 }, "-=0.15")
        .from(el.querySelector(".intro__aside"), { opacity: 0, x: 38, duration: 0.8 }, "-=0.55");
    });

    // 02 — Gallery: heading is uncovered, then the framed artworks rise in sequence.
    roomTrigger(".gallery", (tl, el) => {
      tl.from(el.querySelector(".section-kicker"), { opacity: 0, y: 18, duration: 0.5 })
        .from(el.querySelector(".gallery__heading .room-heading"), { clipPath: "inset(0 0 100% 0)", y: 24, duration: 0.85 }, "-=0.1")
        .from(el.querySelector(".gallery__intro"), { opacity: 0, x: 24, duration: 0.65 }, "-=0.45")
        .from(el.querySelectorAll(".artwork"), { opacity: 0, y: 55, rotate: (i) => i % 2 ? 2.5 : -2.5, scale: 0.97, duration: 0.8, stagger: 0.11, clearProps: "transform" }, "-=0.05")
        .from(el.querySelector(".gallery__footnote"), { opacity: 0, y: 16, duration: 0.55 }, "-=0.15");
    });

    // 03 — Interlude: the archive mark slides across; the quote softly focuses in.
    roomTrigger(".interlude", (tl, el) => {
      tl.from(el.querySelector(".interlude__mark"), { opacity: 0, x: -45, duration: 0.8 })
        .from(el.querySelector(".interlude__quote"), { opacity: 0, y: 35, scale: 0.97, duration: 1.0 }, "-=0.2")
        .from(el.querySelector(".interlude__caption"), { opacity: 0, letterSpacing: "0.3em", duration: 0.65 }, "-=0.3");
    });

    // 04 — Film room: copy enters from the left while the poster unfolds from the right.
    roomTrigger(".film", (tl, el) => {
      tl.from(el.querySelector(".section-kicker"), { opacity: 0, y: 18, duration: 0.5 })
        .from(el.querySelector(".film__copy"), { opacity: 0, x: -50, duration: 0.9 }, "-=0.05")
        .from(el.querySelector(".film__poster"), { opacity: 0, x: 65, rotate: 5, scale: 0.94, duration: 1.0 }, "-=0.55");
    });

    // 05 — Timeline: each memory arrives like a new entry in an archive ledger.
    roomTrigger(".timeline", (tl, el) => {
      tl.from(el.querySelector(".section-kicker"), { opacity: 0, y: 18, duration: 0.5 })
        .from(el.querySelector(".timeline__heading"), { opacity: 0, y: 35, duration: 0.8 }, "-=0.05")
        .from(el.querySelectorAll(".timeline-item"), { opacity: 0, x: (i) => i % 2 ? 32 : -32, y: 10, duration: 0.7, stagger: 0.13 }, "-=0.15");
    });

    // 06 — Masterpiece: the artwork lifts into view inside its frame.
    roomTrigger(".masterpiece", (tl, el) => {
      tl.from(el.querySelector(".masterpiece__label"), { opacity: 0, y: 15, duration: 0.55 })
        .from(el.querySelector(".masterpiece__image"), { opacity: 0, y: 65, scale: 0.92, rotate: -1.5, clipPath: "inset(12% 8% 12% 8%)", duration: 1.1 }, "-=0.05")
        .from(el.querySelector(".masterpiece__stamp"), { opacity: 0, scale: 0.4, rotate: -35, duration: 0.65 }, "-=0.3")
        .from(el.querySelector(".masterpiece__caption"), { opacity: 0, y: 20, duration: 0.65 }, "-=0.25");
    });

    // 07 — Final room: the title opens into view, like the final scene of a film.
    roomTrigger(".closing", (tl, el) => {
      tl.from(el.querySelector(".section-kicker"), { opacity: 0, y: 18, duration: 0.5 })
        .from(el.querySelector(".closing__overline"), { opacity: 0, y: 18, duration: 0.6 })
        .from(el.querySelector(".closing__title"), { clipPath: "inset(0 0 100% 0)", y: 28, duration: 1.0 }, "-=0.15")
        .from(el.querySelector(".closing__message"), { opacity: 0, y: 18, duration: 0.65 }, "-=0.35")
        .from(el.querySelector(".closing__back"), { opacity: 0, y: 12, duration: 0.55 }, "-=0.15");
    });
  }, { scope: root });

  const openArtwork = (index) => setActiveArtwork(index);
  const changeArtwork = (index) => setActiveArtwork(index);

  return (
    <main ref={root}>
      <CinematicGateEntrance />


      <section className="hero" id="home" aria-labelledby="hero-title">
      <header className="site-header">
        <a href="#home" className="wordmark" aria-label="HER, home">H<span>·</span>R</a>
        <div className="header-note">A PRIVATE DIGITAL EXHIBITION</div>
        <button className="menu-toggle icon-button" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label="Toggle navigation"><Menu /></button>
        <nav className={menuOpen ? "site-nav site-nav--open" : "site-nav"} aria-label="Main navigation">
          {[["Gallery", "#gallery"], ["Moving memories", "#film"], ["Timeline", "#timeline"], ["About", "#closing"]].map(([label, href]) =>
            <a key={href} href={href} onClick={() => setMenuOpen(false)}>{label}</a>
          )}
        </nav>
      </header>
        <div className="hero__grain" />
        <div className="hero__content">
          <p className="eyebrow hero__eyebrow"><span className="eyebrow__line" /> AN ONGOING COLLECTION <span>— Nº 001</span></p>
          <h1 id="hero-title" className="hero__title"><span className="hero__title-line">A world</span><span className="hero__title-line hero__title-line--italic">of her own.</span></h1>
          <p className="hero__subtitle">{exhibition.subtitle}</p>
          <a className="hero__scroll" href="#intro"><span>ENTER THE EXHIBITION</span><ArrowDown size={15} strokeWidth={1.4} /></a>
        </div>
        <div className="hero__image-wrap">
          <ParallaxImage className="hero__parallax" src="/assets/gallery/hero.svg" alt="Abstract placeholder artwork for the exhibition" speed={0.08} priority />
          <div className="hero__image-label"><span>FIG. 01</span><span>THE ART OF HER</span></div>
        </div>
        <ParallaxLayer className="hero__floating-label" speed={0.07}>
          <div className="hero__side-note">A STUDY IN LIGHT, MEMORY & PRESENCE</div>
        </ParallaxLayer>
        <div className="hero__index">01 <span>—</span> 07</div>
      </section>

      <section className="intro section-pad" id="intro">
        <div className="section-kicker reveal"><span>01 / THE ENTRANCE</span><span>AN OPENING NOTE</span></div>
        <div className="intro__grid">
          <p className="intro__large reveal">{exhibition.intro}</p>
          <div className="intro__aside reveal"><span className="ornament">✳</span><p>This little museum is made of photographs, passing light, and the things worth keeping.</p><span className="fine-rule" /><span className="micro-label">A PERSONAL ARCHIVE</span></div>
        </div>
      </section>

      <section className="gallery section-pad" id="gallery">
        <div className="section-kicker reveal"><span>02 / THE PORTRAIT GALLERY</span><span>SELECTED WORKS · 06 PIECES</span></div>
        <div className="gallery__heading">
          <h2 className="room-heading">The beautiful<br /><em>ordinary.</em></h2>
          <p className="gallery__intro reveal">A collection of little things that become everything when you look closely.</p>
        </div>
        <div className="gallery__grid">
          {exhibition.gallery.map((item, i) => <Artwork key={item.id} item={item} index={i} onOpen={openArtwork} />)}
        </div>
        <p className="gallery__footnote reveal"><span>✳</span> Every image holds a world of its own.</p>
      </section>

      <section className="interlude">
        <div className="interlude__mark">HER <span>✳</span> HER <span>✳</span> HER <span>✳</span> HER</div>
        <p className="interlude__quote reveal">“The smallest moments are often the ones that stay.”</p>
        <span className="interlude__caption">A NOTE FROM THE ARCHIVE</span>
      </section>

      <section className="film section-pad" id="film">
        <div className="section-kicker reveal"><span>03 / MOVING MEMORIES</span><span>THE FILM ROOM</span></div>
        <div className="film__layout">
          <div className="film__copy">
            <p className="eyebrow reveal">LIFE, IN MOTION</p>
            <h2 className="room-heading">Some things<br />are better <em>moving.</em></h2>
            <p className="film__description reveal">A little motion, a familiar voice, a moment that keeps unfolding. Add your own film to make this room yours.</p>
            <button className="text-link reveal" onClick={() => setVideoOpen(true)}><span>OPEN THE FILM ROOM</span><ArrowRight size={16} /></button>
          </div>
          <button className="film__poster" onClick={() => setVideoOpen(true)} aria-label="Open film room">
            <img src="/assets/posters/video-poster.svg" alt="Abstract placeholder video poster" loading="lazy" />
            <span className="film__play"><Play fill="currentColor" size={18} /></span>
            <span className="film__poster-label">FILM Nº 01 <span>·</span> A MOVING MEMORY</span>
          </button>
        </div>
      </section>

      <section className="timeline section-pad" id="timeline">
        <div className="section-kicker reveal"><span>04 / FRAGMENTS OF TIME</span><span>A PERSONAL TIMELINE</span></div>
        <div className="timeline__heading">
          <h2 className="room-heading">A life made<br /><em>of moments.</em></h2>
          <p className="reveal">Not every memory needs a date. Some only need a place to live.</p>
        </div>
        <div className="timeline__list">
          {exhibition.timeline.map((item, i) => <article className="timeline-item reveal" key={item.id}>
            <div className="timeline-item__meta"><span className="timeline-item__dot" />{item.date || `MOMENT Nº 0${i + 1}`}</div>
            <div className="timeline-item__body"><h3>{item.title}</h3><p>{item.description}</p></div>
            <span className="timeline-item__index">0{i + 1}</span>
          </article>)}
        </div>
      </section>

      <section className="masterpiece section-pad">
        <div className="masterpiece__label reveal"><span>05 / THE MASTERPIECE</span><span>ON PERMANENT DISPLAY</span></div>
        <div className="masterpiece__image reveal"><ParallaxImage src="/assets/gallery/masterpiece.svg" alt="Placeholder artwork for the featured masterpiece" speed={0.06} /><span className="masterpiece__stamp">HER<br /><small>MMXXVI</small></span></div>
        <p className="masterpiece__caption reveal">Not one moment. <em>A thousand little reasons.</em></p>
      </section>

      <footer className="closing section-pad" id="closing">
        <div className="section-kicker reveal"><span>06 / THE FINAL ROOM</span><span>END OF EXHIBITION · NOT THE STORY</span></div>
        <p className="closing__overline reveal">THE COLLECTION CONTINUES</p>
        <h2 className="closing__title room-heading">Some moments<br />are <em>forever.</em></h2>
        <p className="closing__message reveal">{exhibition.closing}</p>
        <a className="closing__back reveal" href="#home">RETURN TO THE BEGINNING <span>↑</span></a>
        <div className="closing__bottom"><span>HER — A PRIVATE DIGITAL MUSEUM</span><span>MADE WITH CARE <span className="gold">✳</span></span><span>END OF EXHIBITION</span></div>
      </footer>

      <Lightbox items={exhibition.gallery} index={activeArtwork} onClose={() => setActiveArtwork(-1)} onChange={changeArtwork} />

      {videoOpen && <div className="video-modal" role="dialog" aria-modal="true" aria-label="Film room">
        <button className="video-modal__close icon-button" onClick={() => setVideoOpen(false)} aria-label="Close film room"><X /></button>
        <div className="video-modal__content">
          <span className="eyebrow">MOVING MEMORIES · FILM ROOM</span>
          <div className="video-modal__screen"><img src="/assets/posters/video-poster.svg" alt="" /><p>Add your video file in <code>public/assets/videos/</code> and update <code>src/content.js</code>.</p></div>
          <button className="text-link" onClick={() => setVideoOpen(false)}>CLOSE EXHIBITION <ArrowRight size={16} /></button>
        </div>
      </div>}
    </main>
  );
}