// Replace the placeholder image paths with your own files in /public/assets/gallery/.
// Keep alt text descriptive. Dates and personal details are intentionally left blank.
export const exhibition = {
  title: "HER",
  subtitle: "A collection of moments, preserved in time.",
  intro: "Some people leave a little light wherever they go.",
  gallery: [
    { id: 1, src: "/assets/gallery/portrait-01.svg", alt: "Placeholder portrait artwork", title: "Study No. 01", caption: "A moment in stillness", frame: "classic", ratio: "portrait" },
    { id: 2, src: "/assets/gallery/moment-02.svg", alt: "Placeholder landscape artwork", title: "Study No. 02", caption: "In another kind of light", frame: "editorial", ratio: "landscape" },
    { id: 3, src: "/assets/gallery/detail-03.svg", alt: "Placeholder abstract detail artwork", title: "Study No. 03", caption: "The smallest details", frame: "floating", ratio: "portrait" },
    { id: 4, src: "/assets/gallery/moment-04.svg", alt: "Placeholder landscape artwork", title: "Study No. 04", caption: "A little piece of forever", frame: "double", ratio: "landscape" },
    { id: 5, src: "/assets/gallery/portrait-05.svg", alt: "Placeholder portrait artwork", title: "Study No. 05", caption: "The art of being here", frame: "masterpiece", ratio: "portrait" },
    { id: 6, src: "/assets/gallery/detail-06.svg", alt: "Placeholder detail artwork", title: "Study No. 06", caption: "Fragments of time", frame: "contact", ratio: "landscape" }
  ],
  videos: [
    { id: 1, title: "Moving memory", description: "Replace this sample with a real video file.", src: "", poster: "/assets/posters/video-poster.svg" }
  ],
  timeline: [
    { id: 1, date: "", title: "A moment in time", description: "Add a memory or leave this entry as a quiet marker." },
    { id: 2, date: "", title: "Another little chapter", description: "Your story, in the order you choose." },
    { id: 3, date: "", title: "Still becoming", description: "Add a date, a photograph, or just a few words." }
  ],
  closing: "Some moments deserve their own room."
};